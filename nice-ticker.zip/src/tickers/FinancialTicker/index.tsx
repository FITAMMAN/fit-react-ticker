/**
 * @component FinancialTicker
 */

import * as React from "react";
import stylesGeneric from '../Ticker/styles.css';
import stylesFinancial from './styles.css';

import chevronUp from '../../images/chevron-up.svg';
import chevronDown from '../../images/chevron-down.svg';
import chevronZero from '../../images/code.svg'


interface IFinancialTrackerProps {
  id: number;
  symbol: string;
  change: boolean;
  identifier?: string; // @TODO
  lastPrice: string;
  currentPrice: string;
  percentage: string;
}


const FinancialTicker: React.FunctionComponent<IFinancialTrackerProps> = (props) => {
  const statusClassName = Number(props.currentPrice) === 0 ? stylesFinancial.tickerChangeZero : (props.change ? stylesFinancial.tickerChangePositive : stylesFinancial.tickerChangeNegative);
  return (
  <div data-id={props.id} className={[stylesGeneric.tickerItem, stylesFinancial.tickerItemFinancial].join(' ')}>
    <div className={stylesFinancial.tickerTopLevel}>
      <div className={stylesFinancial.tickerSymbol}>{props.symbol}</div>
      <div className={stylesFinancial.lastPrice}>{props.lastPrice}</div>
    </div>
    <div className={stylesFinancial.tickerStats}>
      <img width='20px' height='20px' className={stylesFinancial.tickerMovement} src={Number(props.currentPrice) === 0 ? chevronZero : (props.change ? chevronUp : chevronDown)} />      <div className={[statusClassName, stylesFinancial.tickerInfo].join(' ')}>
        <div className={stylesFinancial.tickerChangePercentage}>{props.percentage}</div>
        <div className={stylesFinancial.tickerCurrentPrice}>{props.currentPrice}</div>
      </div>
    </div>
  </div>)
}

export default FinancialTicker;
